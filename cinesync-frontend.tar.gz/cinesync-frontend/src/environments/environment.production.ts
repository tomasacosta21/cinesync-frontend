export const environment = {
  production: true,
  apiUrl: 'https://TU-APP.up.railway.app/api'   // reemplazar antes del deploy
};
