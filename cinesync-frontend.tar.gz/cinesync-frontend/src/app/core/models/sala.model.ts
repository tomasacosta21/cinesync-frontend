export type EstadoButaca = 'LIBRE' | 'RESERVADA' | 'OCUPADA' | 'SELECCIONADA';

export interface Butaca {
  id: string;
  fila: number;
  columna: number;
  estado: EstadoButaca;
}

export interface Sala {
  id: number;
  nombre: string;
  filas: number;
  columnas: number;
  butacas: Butaca[];
}

export interface ReservaRequest {
  usuarioId: string;
  butacaId: string;
}

export interface ReservaResponse {
  exitoso: boolean;
  mensaje: string;
  butacaId: string;
  estado: string;
}

export interface SseEvent {
  salaId: number;
  butacaId: string;
  estado: EstadoButaca;
}
