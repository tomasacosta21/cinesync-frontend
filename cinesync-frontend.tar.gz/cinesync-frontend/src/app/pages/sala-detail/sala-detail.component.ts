import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { SalaService } from '../../core/services/sala.service';
import { SseService } from '../../core/services/sse.service';
import { Sala, Butaca, EstadoButaca } from '../../core/models/sala.model';

@Component({
  selector: 'app-sala-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sala-detail.component.html',
  styleUrls: ['./sala-detail.component.scss']
})
export class SalaDetailComponent implements OnInit, OnDestroy {

  sala?: Sala;
  cargando = true;
  error = false;

  /** IDs de butacas que el usuario seleccionó en esta sesión */
  seleccionadas = new Set<string>();

  /** Toggle para la demo de race condition */
  modoRace = false;
  raceEnProgreso = false;
  raceResultado = '';

  /** Último evento SSE recibido — para el indicador visual */
  ultimoEvento = '';

  private salaId!: number;
  private sseSub?: Subscription;

  /** ID de usuario simulado — en producción vendría de un servicio de auth */
  readonly userId = 'usr-' + Math.random().toString(36).slice(2, 7).toUpperCase();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private salaService: SalaService,
    private sseService: SseService
  ) {}

  ngOnInit(): void {
    this.salaId = Number(this.route.snapshot.paramMap.get('id'));
    this.cargarSala();
  }

  ngOnDestroy(): void {
    this.sseSub?.unsubscribe();
    this.sseService.desconectar();
  }

  // ── Carga inicial ─────────────────────────────────────────

  private cargarSala(): void {
    this.salaService.obtenerSala(this.salaId).subscribe({
      next: sala => {
        this.sala = sala;
        this.cargando = false;
        this.suscribirSSE();
      },
      error: () => {
        this.cargando = false;
        this.error = true;
      }
    });
  }

  // ── SSE — actualizaciones en tiempo real ──────────────────

  private suscribirSSE(): void {
    this.sseSub = this.sseService.conectar(this.salaId).subscribe({
      next: evento => {
        if (!this.sala || evento.salaId !== this.salaId) return;

        const butaca = this.sala.butacas.find(b => b.id === evento.butacaId);
        if (!butaca) return;

        // Si alguien más reservó una butaca que yo tenía seleccionada → la quito
        if (evento.estado !== 'LIBRE' && this.seleccionadas.has(butaca.id)) {
          this.seleccionadas.delete(butaca.id);
        }

        butaca.estado = evento.estado;
        this.ultimoEvento = `${evento.butacaId} → ${evento.estado}`;

        // Limpia el indicador tras 2s
        setTimeout(() => { this.ultimoEvento = ''; }, 2000);
      },
      error: () => {
        // Reconexión silenciosa tras 3s
        setTimeout(() => this.suscribirSSE(), 3000);
      }
    });
  }

  // ── Interacción con butacas ───────────────────────────────

  seleccionar(butaca: Butaca): void {
    if (butaca.estado === 'OCUPADA' || butaca.estado === 'RESERVADA') return;

    if (this.seleccionadas.has(butaca.id)) {
      this.seleccionadas.delete(butaca.id);
      butaca.estado = 'LIBRE';
    } else {
      this.seleccionadas.add(butaca.id);
      butaca.estado = 'SELECCIONADA';
    }
  }

  confirmarReserva(): void {
    if (!this.sala || this.seleccionadas.size === 0) return;

    const ids = Array.from(this.seleccionadas);
    this.seleccionadas.clear();

    ids.forEach(butacaId => {
      this.salaService.reservar(this.salaId, {
        usuarioId: this.userId,
        butacaId
      }).subscribe(resp => {
        if (resp.exitoso) {
          // Simula un paso de pago con 1.5s de delay antes de confirmar
          setTimeout(() => {
            this.salaService.confirmar(this.salaId, butacaId).subscribe();
          }, 1500);
        } else {
          // El backend rechazó la reserva (otra persona se adelantó)
          const b = this.sala?.butacas.find(b => b.id === butacaId);
          if (b) b.estado = 'LIBRE';
        }
      });
    });
  }

  cancelarSeleccion(): void {
    if (!this.sala) return;
    this.seleccionadas.forEach(id => {
      const b = this.sala!.butacas.find(b => b.id === id);
      if (b) b.estado = 'LIBRE';
    });
    this.seleccionadas.clear();
  }

  // ── Demo: Race Condition ──────────────────────────────────

  /**
   * Lanza N peticiones simultáneas sobre la misma butaca libre.
   * Con ReentrantLock activo en el backend → exactamente 1 gana.
   * El SSE propaga el resultado a todos los clientes en tiempo real.
   */
  simularRaceCondition(): void {
    if (!this.sala || this.raceEnProgreso) return;

    const libreAleatoria = this.sala.butacas.find(b => b.estado === 'LIBRE');
    if (!libreAleatoria) {
      this.raceResultado = 'No hay butacas libres para la demo.';
      return;
    }

    this.raceEnProgreso  = true;
    this.modoRace        = true;
    this.raceResultado   = '';
    const N = 15;

    const requests = Array.from({ length: N }, (_, i) =>
      this.salaService.reservar(this.salaId, {
        usuarioId: `race-${i}`,
        butacaId:  libreAleatoria.id
      })
    );

    let exitosos = 0;
    let completados = 0;

    requests.forEach(req$ => {
      req$.subscribe(resp => {
        if (resp.exitoso) exitosos++;
        completados++;
        if (completados === N) {
          this.raceResultado =
            `${N} hilos compitieron por ${libreAleatoria.id} → ${exitosos} ganó (esperado: 1)`;
          this.raceEnProgreso = false;
          setTimeout(() => { this.modoRace = false; this.raceResultado = ''; }, 5000);
        }
      });
    });
  }

  // ── Helpers de vista ──────────────────────────────────────

  clasePara(butaca: Butaca): string {
    if (this.seleccionadas.has(butaca.id)) return 'seleccionada';
    return butaca.estado.toLowerCase();
  }

  contarPorEstado(estado: EstadoButaca | string): number {
    return this.sala?.butacas.filter(b => b.estado === estado).length ?? 0;
  }

  idsSeleccionadas(): string {
    return Array.from(this.seleccionadas).join(', ');
  }

  filas(): number[] {
    if (!this.sala) return [];
    return Array.from({ length: this.sala.filas }, (_, i) => i);
  }

  butacasDeFila(filaIdx: number): Butaca[] {
    return this.sala?.butacas.filter(b => b.fila === filaIdx) ?? [];
  }

  letraFila(filaIdx: number): string {
    return String.fromCharCode(65 + filaIdx);
  }

  volver(): void {
    this.router.navigate(['/salas']);
  }
}
